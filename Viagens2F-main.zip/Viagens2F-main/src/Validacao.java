public class Validacao {
    public static boolean cpf(String s) {
        return true;
    }
}
